<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="<?php echo get_template_directory_uri(); ?>/assets/favicon.png" type="image/gif">
    <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<header class="header_section innerpage_header">
    <div >
        <nav class="navbar navbar-expand-lg custom_nav-container">
            <a class="navbar-brand" href="<?php echo home_url(); ?>">
                <span>Healet</span>
            </a>
            <div class="" id="">
                <div class="custom_menu-btn">
                    <button onclick="openNav()">
                        <span class="s-1"> </span>
                        <span class="s-2"> </span>
                        <span class="s-3"> </span>
                    </button>
                    <div id="myNav" class="overlay">
                        <div class="overlay-content">
                            <a href="<?php echo home_url(); ?>">home</a>
                            <a href="<?php echo get_permalink(get_page_by_path('about')); ?>">About</a>
                            <a href="<?php echo get_permalink(get_page_by_path('shop')); ?>">Shop</a>
                            <a href="<?php echo get_permalink(get_page_by_path('blog')); ?>">Blog</a>
                        </div>
                    </div>
                </div>
            </div>
        </nav>
    </div>
</header>
