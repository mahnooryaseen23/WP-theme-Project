<?php
// This is the main template file
get_header(); ?>

<h1>Welcome to the Jewellery Web Site Theme</h1>

<?php
get_footer();
