<?php
/*
Template Name: Home Page
*/
get_header(); 
?>


<section class="slider_section position-relative">
    <div class="slider_bg_box">
    <img src="<?php echo get_template_directory_uri(); ?>/assets/slider-bg.jpg" >
    </div>
    <div class="container">
        <div class="col-md-9 col-lg-8">
            <div class="detail-box">
                <h1>Best Jewellery<br> Collection</h1>
                <p>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem</p>
                <div>
                    <a href="" class="slider-link">Shop Now</a>
                </div>
            </div>
        </div>
    </div>
</section>
<section class="shop_section layout_padding">
    <div class="container">
        <div class="heading_container heading_center">
            <h2>Latest Products</h2>
        </div>
        <div class="row">
            <?php if ( have_rows('products') ): while ( have_rows('products') ) : the_row(); ?>
                <div class="col-sm-6 col-md-4 col-lg-3">
                    <div class="box">
                        <a href="<?php the_sub_field('product_link'); ?>">
                            <div class="img-box">
                                <img src="<?php the_sub_field('product_image'); ?>" alt="">
                            </div>
                            <div class="detail-box">
                                <h6><?php the_sub_field('product_name'); ?></h6>
                                <h6>Price <span>$<?php the_sub_field('product_price'); ?></span></h6>
                            </div>
                            <div class="new">
                                <span>New</span>
                            </div>
                        </a>
                    </div>
                </div>
            <?php endwhile; endif; ?>
        </div>
        <div class="btn-box">
            <a href="<?php echo site_url('/shop'); ?>">View All Products</a>
        </div>
    </div>
</section>
<section class="about_section">
    <div class="container">
        <div class="row">
            <div class="col-md-6">
                <div class="img-box">
                <img src="<?php echo get_template_directory_uri(); ?>/assets/about-img.jpg" >
                </div>
            </div>
            <div class="col-md-6">
                <div class="detail-box">
                    <div class="heading_container">
                        <h2>About Us</h2>
                    </div>
                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Corrupti dolorem eum consequuntur ipsam repellat dolor soluta aliquid laborum, eius odit consectetur vel quasi in quidem, eveniet ab est corporis tempore.</p>
                    <a href="<?php echo site_url('/about'); ?>">Read More</a>
                </div>
            </div>
        </div>
    </div>
</section>


<section class="offer_section layout_padding">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-7 px-0">
                <div class="box offer-box1">
<img src="<?php echo get_template_directory_uri(); ?>/assets/o1.jpg" >
                    <div class="detail-box">
                        <h2>Upto 15% Off</h2>
                        <a href="">Shop Now</a>
                    </div>
                </div>
            </div>
            <div class="col-md-5 px-0">
                <div class="box offer-box2">
                <img src="<?php echo get_template_directory_uri(); ?>/assets/o2.jpg" >
                <div class="detail-box">
                        <h2>Upto 10% Off</h2>
                        <a href="">Shop Now</a>
                    </div>
                </div>
                <div class="box offer-box3">
                <img src="<?php echo get_template_directory_uri(); ?>/assets/o3.jpg"  >
                <div class="detail-box">
                        <h2>Upto 20% Off</h2>
                        <a href="">Shop Now</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="blog_section ">
    <div class="container">
      <div class="heading_container">
        <h2>
          Latest From Blog
        </h2>
      </div>
      <div class="row">
        <div class="col-md-6">
          <div class="box">
            <div class="img-box">
            <img src="<?php echo get_template_directory_uri(); ?>/assets/b1.jpg">              <h4 class="blog_date">
                14 <br>
                July
              </h4>
            </div>
            <div class="detail-box">
              <h5>
                Molestiae ad reiciendis dignissimos
              </h5>
              <p>
                alteration in some form, by injected humour, or randomised words which don't look even slightly believable.
              </p>
              <a href="">
                Read More
              </a>
            </div>
          </div>
        </div>
        <div class="col-md-6">
          <div class="box">
            <div class="img-box">
            <img src="<?php echo get_template_directory_uri(); ?>/assets/b2.jpg">              <h4 class="blog_date">
                15 <br>
                July
              </h4>
            </div>
            <div class="detail-box">
              <h5>
                Dolores vel maiores voluptatem enim
              </h5>
              <p>
                alteration in some form, by injected humour, or randomised words which don't look even slightly believable.
              </p>
              <a href="">
                Read More
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>

<section class="client_section layout_padding">
    <div class="container">
        <div class="heading_container">
            <h2>Testimonial</h2>
        </div>
        <div id="carouselExample2Controls" class="carousel slide" data-ride="carousel">
            <div class="carousel-inner">
              
                <div class="carousel-item">
                    <div class="row">
                        <div class="col-md-11 col-lg-10 mx-auto">
                            <div class="box">
                                <div class="img-box">
                                <img src="<?php echo get_template_directory_uri(); ?>/assets/client.jpg" >
                                </div>
                                <div class="detail-box">
                                    <div class="name">
                                        <h6>Samantha Jonas</h6>
                                    </div>
                                    <p>It is a long established fact that a reader will be distracted by the readable cIt is a long established fact that a reader will be distracted by the readable c</p>
                                    <i class="fa fa-quote-left" aria-hidden="true"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="carousel-item active">
                    <div class="row">
                        <div class="col-md-11 col-lg-10 mx-auto">
                            <div class="box">
                                <div class="img-box">
                                <img src="<?php echo get_template_directory_uri(); ?>/assets/client.jpg" >
                                </div>
                                <div class="detail-box">
                                    <div class="name">
                                        <h6>Samantha Jonas</h6>
                                    </div>
                                    <p>It is a long established fact that a reader will be distracted by the readable cIt is a long established fact that a reader will be distracted by the readable c</p>
                                    <i class="fa fa-quote-left" aria-hidden="true"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <a class="carousel-control-prev" href="#carouselExample2Controls" role="button" data-slide="prev">
                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                <span class="sr-only">Previous</span>
            </a>
            <a  class="carousel-control-next" href="#carouselExample2Controls" role="button" data-slide="next">
                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                <span class="sr-only">Next</span>
            </a>
        </div>
    </div>
</section>

<?php get_footer();  ?>
