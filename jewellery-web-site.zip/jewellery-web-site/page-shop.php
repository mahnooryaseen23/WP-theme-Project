<?php
/*
Template Name: Shop Page
*/
get_header(); 
?>

<section class="shop_section layout_padding">
  <div class="container">
    <div class="heading_container heading_center">
      <h2>Latest Products</h2>
    </div>
    <div class="row">
      <div class="col-sm-6 col-md-4 col-lg-3">
        <div class="box">
          <a href="">
            <div class="img-box">
              <img src="<?php echo get_template_directory_uri(); ?>/assets/p1.png">
            </div>
            <div class="detail-box">
              <h6>Necklace</h6>
              <h6>Price <span>$200</span></h6>
            </div>
            <div class="new"><span>New</span></div>
          </a>
        </div>
      </div>
      
      <div class="col-sm-6 col-md-4 col-lg-3">
        <div class="box">
          <a href="">
            <div class="img-box">
            <img src="<?php echo get_template_directory_uri(); ?>/assets/p2.png">            </div>
            <div class="detail-box">
              <h6>Chain</h6>
              <h6>Price <span>$300</span></h6>
            </div>
            <div class="new"><span>New</span></div>
          </a>
        </div>
      </div>
      

      <div class="col-sm-6 col-md-4 col-lg-3">
        <div class="box">
          <a href="">
            <div class="img-box">
            <img src="<?php echo get_template_directory_uri(); ?>/assets/p3.png">            </div>
            <div class="detail-box">
              <h6>Chain</h6>
              <h6>Price <span>$400</span></h6>
            </div>
            <div class="new"><span>New</span></div>
          </a>
        </div>
      </div>
      <div class="col-sm-6 col-md-4 col-lg-3">
        <div class="box">
          <a href="">
            <div class="img-box">
            <img src="<?php echo get_template_directory_uri(); ?>/assets/p4.png">            </div>
            <div class="detail-box">
              <h6>Chain</h6>
              <h6>Price <span>$100</span></h6>
            </div>
            <div class="new"><span>New</span></div>
          </a>
        </div>
      </div>


      <div class="col-sm-6 col-md-4 col-lg-3">
        <div class="box">
          <a href="">
            <div class="img-box">
            <img src="<?php echo get_template_directory_uri(); ?>/assets/p5.png">            </div>
            <div class="detail-box">
              <h6>Chain</h6>
              <h6>Price <span>$300</span></h6>
            </div>
          </a>
        </div>
      </div>


      <div class="col-sm-6 col-md-4 col-lg-3">
        <div class="box">
          <a href="">
            <div class="img-box">
            <img src="<?php echo get_template_directory_uri(); ?>/assets/p6.png">            </div>
            <div class="detail-box">
              <h6>Chain</h6>
              <h6>Price <span>$500</span></h6>
            </div>
          </a>
        </div>
      </div>

      <div class="col-sm-6 col-md-4 col-lg-3">
        <div class="box">
          <a href="">
            <div class="img-box">
            <img src="<?php echo get_template_directory_uri(); ?>/assets/p7.png">            </div>
            <div class="detail-box">
              <h6>Chain</h6>
              <h6>Price <span>$300</span></h6>
            </div>
          </a>
        </div>
      </div>

      <div class="col-sm-6 col-md-4 col-lg-3">
        <div class="box">
          <a href="">
            <div class="img-box">
            <img src="<?php echo get_template_directory_uri(); ?>/assets/p8.png">            </div>
            <div class="detail-box">
              <h6>Chain</h6>
              <h6>Price <span>$300</span></h6>
            </div>
          </a>
        </div>
      </div>



    </div>
    <div class="btn-box">
      <a href="">View All Products</a>
    </div>
  </div>
</section>


<?php
get_footer();
?>
