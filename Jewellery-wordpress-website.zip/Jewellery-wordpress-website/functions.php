




<?php

// Function to enqueue styles
function theme_enqueue_styles_scripts() {
    wp_enqueue_style('font-awesome', 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css');


    // Enqueue Bootstrap (choose CDN version or local, not both)
    wp_enqueue_style('bootstrap-css', 'https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css');

    // Enqueue Custom Styles
    wp_enqueue_style('custom-style', get_template_directory_uri() . '/css/style.css');
    wp_enqueue_style('responsive-style', get_template_directory_uri() . '/css/responsive.css');

    // Enqueue jQuery (WordPress includes jQuery by default, no need to specify a source)
    wp_enqueue_script('jquery');

    // Enqueue Bootstrap JS (from CDN)
    wp_enqueue_script('bootstrap-js', 'https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js', array('jquery'), null, true);

    // Enqueue Custom JS
    wp_enqueue_script('custom-js', get_template_directory_uri() . '/js/custom.js', array('jquery'), null, true);

    // Additional JS if needed
    wp_enqueue_script('additional-js', get_template_directory_uri() . '/js/additional.js', array('jquery'), null, true);
}
add_action('wp_enqueue_scripts', 'theme_enqueue_styles_scripts');

?>





